This is an easy PHP calendar that pulls data from MYSQL.  

Full Tutorial at http://codebangers.com/?p=695. Enjoy
