<img src="<?php echo URL_BASE; ?>public/img/logo.png" class="logo" />
