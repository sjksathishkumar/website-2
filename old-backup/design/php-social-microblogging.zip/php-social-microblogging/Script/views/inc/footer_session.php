<span class="grid_title_small" style="margin-bottom: 0;">&copy; <?php echo date('Y')." ".SITE_NAME; ?></span>
	<div class="footer_responsive">
		<a class="link_small" href="<?php echo URL_BASE; ?>advertising/">Advertising</a>
		<a class="link_small" href="<?php echo URL_BASE; ?>about/">About Us</a>
		<a class="link_small" href="<?php echo URL_BASE; ?>terms/">Terms</a>
		<a class="link_small" href="<?php echo URL_BASE; ?>privacy/">Privacy</a>
		<a class="link_small" href="<?php echo URL_BASE; ?>help/">Help</a>
	</div>