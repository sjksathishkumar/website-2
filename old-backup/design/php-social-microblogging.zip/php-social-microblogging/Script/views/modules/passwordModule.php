<div class="containerForm">
	
	<form class="formAjax" action="" method="POST" id="formSettings">
	<!-- Grid Form  -->
	<div class="grid-form" style="padding-top: 15px;">
		<span id="checkusername"></span>
		<label>Current password</label>
		<input type="password" name="current" id="current" value="" />
	</div><!-- Grid Form  -->
		
		<!-- Grid Form  -->
	<div class="grid-form">
		<label>New password</label>
		<input type="password" name="new" id="new" value="" />
	</div><!-- Grid Form  -->
	
	<!-- Grid Form  -->
	<div class="grid-form">
		<label style="line-height: 15px;">Confirm password</label>
		<input type="password" name="confirm" id="confirm" value="" />
	</div><!-- Grid Form  -->
	
	
	<div class="error-update"></div>
	
	<div id="counter"></div>
	  <button id="editProfile" class="profile-settings-password" disabled="disabled" style="opacity: 0.5; cursor: default;" type="submit">Save</button>
	</form>
	

</div><!-- Container Form -->
