<ul class="posts">
	<?php if( $this->countMgs == 0 ): ?>
		<span class="notfound">without messages!</span>
		<?php endif; ?>
</ul>


