<div class="content">
	<span class="titleBar">
			Edit Pages &raquo;
		</span>
<table cellpadding="0" cellspacing="0" border="0" class="dTable">
                <thead>
                <tr>
                	<th>Page</th>
		            <th>Actions</th>
                </tr>
                </thead>
                <tbody>
        
               <tr>
					<td>Help</td>
					<td><a href="admin/?edit=1">Edit</a></td>
				</tr>
               	     
               	<tr>
					<td>Terms</td>
					<td><a href="admin/?edit=2">Edit</a></td>
				</tr>
				
				<tr>
					<td>Privacy</td>
					<td><a href="admin/?edit=3">Edit</a></td>
				</tr>
				
				<tr>
					<td>Advertising</td>
					<td><a href="admin/?edit=4">Edit</a></td>
				</tr>
				
				<tr>
					<td>About</td>
					<td><a href="admin/?edit=5">Edit</a></td>
				</tr>
				
                	</tbody>
                </table> 


	
</div><!-- End Content -->