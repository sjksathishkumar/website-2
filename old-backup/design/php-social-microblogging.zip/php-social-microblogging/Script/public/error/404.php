<h4 style="font-size: 18px; text-align: center; color: #666;;  font-family: sans-serif, Arial; padding: 20px;">
	<span style="font-size: 50px; color: #F00;">Error 404</span><br /> Sorry, that page does not found!
	</h3>
